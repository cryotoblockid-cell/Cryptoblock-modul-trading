# CryptoBlock.idn — Modul Trading Crypto

Website statis satu halaman. Tidak membutuhkan database atau backend.

## Cara menjalankan
Buka `index.html` di browser.

## Cara membuatnya online gratis
Upload file `index.html` ke layanan hosting statis seperti GitHub Pages atau Cloudflare Pages.
